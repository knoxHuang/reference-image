'use strict';

module.exports = {
    entry_tips: 'Whether to display the reference map',
};
